import os
import sys

print("lat,lon,temp34,prec34,temp56,prec56")

file = open("target_points.csv", "r")
target_points = file.readlines()
target_points = target_points[1:] 
 
for point in target_points:
    print(point.strip() + ",0,0,0,0")
                 