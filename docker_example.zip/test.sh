python3 baseline.py "$1" > "$2"
